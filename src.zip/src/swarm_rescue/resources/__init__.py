import os

path_resources = os.path.dirname(os.path.abspath(__file__))
