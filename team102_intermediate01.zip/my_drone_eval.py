from swarm_rescue.solutions.my_drone_prototype import MyDronePrototype


class MyDroneEval(MyDronePrototype):
    """
    Evaluation drone class that inherits from MyDroneRandom.

    This class can be extended to implement custom evaluation logic.
    """

    pass